import React from "react";

const Register = () => {
  return (
    <div>
      <p
        style={{
          color: "red",
          height: "500px",
          backgroundColor: "yellow",
          fontSize: "40px",
        }}
      >
        {" "}
        slAM{" "}
      </p>

      <h1 style={{ backgroundColor: "Tomato" }}>Tomato</h1>
      <h1 style={{ backgroundColor: "Orange" }}>Orange</h1>
      <h1 style={{ backgroundColor: "DodgerBlue" }}>DodgerBlue</h1>
      <h1 style={{ backgroundColor: "Gray" }}>Gray</h1>
      <h1 style={{ backgroundColor: "SlateBlue" }}>SlateBlue</h1>
      <h1 style={{ backgroundColor: "Violet" }}>Violet</h1>
      <h1 style={{ backgroundColor: "LightGray" }}>LightGray</h1>
    </div>
  );
};

export default Register;
