import React from "react";
import Child from "./Child";
import About from "./About";

const Contact = () => {
  return (
    <div>
      <About />
      <Child />
      <h1> فوتر سایت 11111</h1>
    </div>
  );
};

export default Contact;
